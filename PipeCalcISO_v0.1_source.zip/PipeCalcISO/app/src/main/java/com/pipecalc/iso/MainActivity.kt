package com.pipecalc.iso

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.max

private val Navy=Color(0xFF071D38); private val Blue=Color(0xFF146EF5); private val Green=Color(0xFF14A66A); private val Bg=Color(0xFFF4F7FB)
data class PipeSpec(val a:String,val nps:String,val od:Double,val sch:String,val t:Double){ val id get()=od-2*t }
val specs=listOf(
 PipeSpec("25A","1\"",33.4,"10S",2.77),PipeSpec("50A","2\"",60.5,"10S",2.77),PipeSpec("80A","3\"",89.1,"10S",3.05),
 PipeSpec("100A","4\"",114.3,"10S",3.05),PipeSpec("150A","6\"",168.3,"10S",3.40),PipeSpec("200A","8\"",219.1,"10S",3.76),
 PipeSpec("100A","4\"",114.3,"40S",6.02),PipeSpec("150A","6\"",168.3,"40S",7.11),PipeSpec("200A","8\"",219.1,"40S",8.18))

class MainActivity:ComponentActivity(){ override fun onCreate(b:Bundle?){super.onCreate(b);setContent{MaterialTheme{App()}}} }
@Composable fun App(){var tab by remember{mutableIntStateOf(0)}; Scaffold(bottomBar={NavigationBar(containerColor=Color.White){listOf("홈","ISO","계산기","DB").forEachIndexed{i,s->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Text(if(i==0)"⌂" else if(i==1)"⌁" else if(i==2)"▦" else "▤")},label={Text(s)})}}}){p->Box(Modifier.padding(p).fillMaxSize().background(Bg)){when(tab){0->Home{tab=it};1->Iso();2->Calc();else->Db()}}}}
@Composable fun Header(t:String)=Box(Modifier.fillMaxWidth().background(Navy).padding(18.dp)){Text(t,color=Color.White,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleLarge)}
@Composable fun Home(go:(Int)->Unit){Column{Header("PipeCalc ISO");Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("배관 치수 계산부터 ISO 작성까지",fontWeight=FontWeight.Bold);Menu("ISO 작성하기","배관 루트를 추가하고 ISO를 그립니다",Blue){go(1)};Menu("배관 계산기","OD · 두께 · ID · 절단길이",Green){go(2)};Menu("규격 · 피팅 DB","제조사/규격 데이터를 확인합니다",Color(0xFFF28B19)){go(3)};Card{Column(Modifier.padding(16.dp)){Text("1차 테스트 버전",fontWeight=FontWeight.Bold);Text("오프라인 규격 DB · ISO 스케치 · 90° LR 절단길이 계산")}}}}}
@Composable fun Menu(a:String,b:String,c:Color,on:()->Unit){Button(onClick=on,colors=ButtonDefaults.buttonColors(containerColor=c),shape=RoundedCornerShape(14.dp),modifier=Modifier.fillMaxWidth().height(86.dp)){Column(Modifier.fillMaxWidth()){Text(a,fontWeight=FontWeight.Bold);Text(b)}}}
@Composable fun SpecPicker():PipeSpec{var a by remember{mutableStateOf("100A")};var sch by remember{mutableStateOf("10S")};val av=specs.map{it.a}.distinct();Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){SimpleDrop("호칭경",a,av){a=it};SimpleDrop("SCH",sch,specs.filter{it.a==a}.map{it.sch}.distinct()){sch=it}};return specs.firstOrNull{it.a==a&&it.sch==sch}?:specs.first{it.a==a}}
@Composable fun SimpleDrop(label:String,v:String,items:List<String>,set:(String)->Unit){var ex by remember{mutableStateOf(false)};Box{OutlinedButton({ex=true}){Text("$label  $v")};DropdownMenu(ex,{ex=false}){items.forEach{DropdownMenuItem({Text(it)},{set(it);ex=false})}}}}
@Composable fun Iso(){var segs by remember{mutableStateOf(listOf(800,600,500))};Column{Header("ISO 작성");Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)){val s=SpecPicker();Text("SUS304  ${s.a} (${s.nps})  SCH${s.sch}",fontWeight=FontWeight.Bold);Card{IsoCanvas(segs)};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button({segs=segs+500},Modifier.weight(1f)){Text("+ 직관")};Button({segs=segs.dropLast(1)},Modifier.weight(1f),enabled=segs.size>1){Text("실행취소")}};Text("구성",fontWeight=FontWeight.Bold);segs.forEachIndexed{i,x->Text("${i+1}. 직관 ${x} mm${if(i<segs.lastIndex)"  →  90° 엘보" else "  →  플랜지"}")};Text("※ 1차 버전 ISO 스케치입니다. 45°/TEE/Reducer/자유방향은 다음 확장 구조로 설계되어 있습니다.",style=MaterialTheme.typography.bodySmall)}}}
@Composable fun IsoCanvas(segs:List<Int>){Canvas(Modifier.fillMaxWidth().height(330.dp).padding(20.dp)){val pts=mutableListOf(Offset(35f,70f));var p=pts[0];segs.forEachIndexed{i,_->p=when(i%3){0->Offset(p.x+220,p.y+80);1->Offset(p.x,p.y+150);else->Offset(p.x-150,p.y+70)};pts+=p};for(i in 0 until pts.lastIndex)drawLine(Navy,pts[i],pts[i+1],18f,StrokeCap.Round);pts.forEach{drawCircle(Blue,10f,it)} }}
@Composable fun Calc(){var cc by remember{mutableStateOf("1000")};Column{Header("배관 계산기");Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)){val s=SpecPicker();Card{Column(Modifier.padding(16.dp)){Text("선택 배관",fontWeight=FontWeight.Bold);Text("SUS304  ${s.a} (${s.nps}) SCH${s.sch}");Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("외경 OD");Text("${s.od} mm",fontWeight=FontWeight.Bold)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("두께 t");Text("${s.t} mm",fontWeight=FontWeight.Bold)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("내경 ID");Text("%.2f mm".format(s.id),fontWeight=FontWeight.Bold)}}};Text("90° LR 엘보 - 엘보 사이 절단길이",fontWeight=FontWeight.Bold);OutlinedTextField(cc,{cc=it.filter(Char::isDigit)},label={Text("센터-센터 거리 (mm)")},modifier=Modifier.fillMaxWidth());val clr=1.5*(s.nps.trim('"').toDoubleOrNull()?:4.0)*25.4;val cut=max(0.0,(cc.toDoubleOrNull()?:0.0)-2*clr);Card{Column(Modifier.padding(18.dp)){Text("LR Center-to-End (계산 기준)");Text("%.1f mm".format(clr));Text("절단 길이",fontWeight=FontWeight.Bold);Text("%.1f mm".format(cut),color=Blue,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.headlineMedium)}};Text("계산식: C-C − (엘보 Take-out × 2)",style=MaterialTheme.typography.bodySmall)}}}
@Composable fun Db(){Column{Header("규격 · 제조사 DB");Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("제조사 DB 슬롯",fontWeight=FontWeight.Bold);listOf("성광벤드","TK Corporation (태광)","진일벤드","대경벤드","동양벤드","삼성스텐레스상공","부산피팅","SBC 벤드","화진피에프","AJFF").forEach{Card{Row(Modifier.fillMaxWidth().padding(16.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(it,fontWeight=FontWeight.Bold);Text("DB 준비",color=Blue)}}};Text("현재 테스트 규격",fontWeight=FontWeight.Bold);specs.forEach{Text("${it.a} (${it.nps}) SCH${it.sch}   OD ${it.od} / t ${it.t} / ID %.2f mm".format(it.id))}}}}
